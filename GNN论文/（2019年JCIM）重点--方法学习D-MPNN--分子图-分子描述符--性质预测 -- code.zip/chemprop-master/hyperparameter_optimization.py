"""Optimizes hyperparameters using Bayesian optimization."""

from chemprop.hyperparameter_optimization import chemprop_hyperopt

if __name__ == '__main__':
    chemprop_hyperopt()
