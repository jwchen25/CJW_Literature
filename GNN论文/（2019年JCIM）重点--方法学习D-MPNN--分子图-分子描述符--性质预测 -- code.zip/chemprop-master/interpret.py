"""Uses MCTS to interpret a chemprop model."""

from chemprop.interpret import chemprop_interpret


if __name__ == '__main__':
    chemprop_interpret()
